
  window.addEventListener("load", function () {
    let formSection = document.querySelector(".form-section");
  let findButton = formSection.querySelector(".btn-find")
  let inputQuery = formSection.querySelector(".input-query");

  findButton.onclick = function (e) {
    e.preventDefault();

    let query = inputQuery.value;

    let request = new XMLHttpRequest();
    //request.open
    //인자는 ("요청하는 방식", "요청할 주소", 비동기 방식에 대한 참/거짓)

    request.open("GET", `/api/menus?q=${query}`, true);
    request.onload=function(){
    //데이터가 로드 되면 실행이 된다.
      console.log(request.responseText);
    };
    request.send();
      console.log("watame");
  };
});



  // window.addEventListener("load", function () {
  //
  //   let menuButton = document.querySelector(".category-search");
  //   let coffee = menuButton.querySelector(".coffee");
  //   let handmade = menuButton.querySelector(".handmade");
  //   let sandwich = menuButton.querySelector(".sandwich");
  //   let cookie = menuButton.querySelector(".cookie");
  //   coffee.onclick = function (e) {
  //     e.preventDefault();
  //
  //     let query = coffee.value;
  //
  //     console.log(query);
  //
  //   };
  //   handmade.onclick = function (e) {
  //     e.preventDefault();
  //
  //     let query = handmade.value;
  //
  //     console.log(query);
  //
  //   };
  //   sandwich.onclick = function (e) {
  //     e.preventDefault();
  //
  //     let query = sandwich.value;
  //
  //     console.log(query);
  //
  //   };
  //   cookie.onclick = function (e) {
  //     e.preventDefault();
  //
  //     let query = cookie.value;
  //
  //     console.log(query);
  //
  //   };
  // });
